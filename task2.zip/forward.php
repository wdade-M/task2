<?php
 include('database_connect.php');
$forward= $_POST["forward"];
echo'f';
?>