<?php
 include('database_connect.php');
$left= $_POST["left"];
echo'l';
?>