<?php
 include('database_connect.php');
$right  =$_POST["right"];
echo'r';
?>
