<?php
include('database_connect.php');
?>
<style>
    body{
        background-image:url("h.jpg") ;
     
        background-position:right top;
    }
    .active{
    font-size: 70px;
}
.dropdown{
    font-size: 30px;
}
</style>

            <a class="active" href="index.php">الرئسيه</a>
            <div class="dropdown">
                <div class="dropdown-content">
                    <p><a href="yindex.php?t=one"> لوحة التحكم في الريبورت</a></p>
                    <p><a href="t2.php?t=two">لوحة التحكم في تحريك الريبورت</a></p>
                </div>
                
