<?php

include('index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<style>
   button {
    background-color: #3306fad0;
    color: white;
    padding: 40px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 20%;
    font-size: large;
}
   #c{
text-align: center;

   }
   body{
       background-color: rgba(155, 150, 224, 0.281);
   }   
  button{
    position: absolute;

      color: #000;
      font-size: 32px;
     font-weight: bold; 
    background:rgba(3, 218, 146, 0.226) ;
    box-shadow: inset 2px 2px  10px rgb(31, 88, 9);
  }
   #left{
       
      border-radius: 53px;
      position: absolute;
      left: 260px;
      bottom: 500px;;
   }
   #stop{
   bottom: 500px;
   left: 990px;
    border-radius: 53px;
   }
   #right{
    right:100px;
    bottom: 500px;
    border-radius: 53px;
   }
   #forward{
  top: 400px;
  left: 990px;
    border-radius: 53px;
   }
   #Backward {
    left: 990px;
   top: 780px;
    border-radius: 53px;
   
   }
    </style>

<body>

<div class="c">
   <form action="left.php" method="post">
<button id="left" name="left">left</button> </form>

<form action="forward.php" method="post">
<button id="forward" name="forward">forward</button></form>
<form action="Backward.php" method="post">
<button id="Backward" name="Backward">Backward </button> </form>
<form action="right.php" method="post">
<button id="right" name="stop">right</button> </form>
<form action="stop.php" method="post">
<button id="stop" name="stop">stop</button> </form>
</div>
</body>

</html>
