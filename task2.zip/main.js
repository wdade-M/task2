const sliders =document.querySelectorAll('.slidere');

sliders.forEach(slider=>{

    slider.addEventListener('input' ,()=>{
        slider.lastElementChild.innerHTML =slider.firstElementChild.value
        
    })
})
