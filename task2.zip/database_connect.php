<?php

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "motors";

// Create connection
$conn = new mysqli($servername , $username, $password, $dbname);
//!--$create_db=$conn->query("CRE");>
// Check connection
if ($conn->connect_error) {
  die("توجد مشكله في الاتصال " . $conn->connect_error);
}
else{
    echo" تم الاتصال بنجاح <br><br>";
    
}


?>
