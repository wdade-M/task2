<?php
 include('database_connect.php');
$stop= $_POST["stop"];
echo 's';
?>