<?php
 include('database_connect.php');
$Backward= $_POST["Backward"];
echo'b';
?>